-- 1) Add an optional PDF URL to each notice.
ALTER TABLE public.cuh_notices
ADD COLUMN IF NOT EXISTS pdf_url TEXT;

-- 2) Make sure the public website can read the column through the
-- existing cuh_notices SELECT policy. No new RLS policy is needed if
-- your current public notice SELECT policy already works.

-- 3) Notice PDFs are uploaded to the existing public Storage bucket:
--    cuh-photo / notice-pdfs/
-- If PDF upload from the admin panel is rejected by Storage RLS,
-- check the existing authenticated INSERT policy for cuh-photo.
-- Do not remove your working teacher/gallery/settings Storage policies.
