import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";

const quickLinks = [
  { to: "/", label: "হোম" },
  { to: "/about", label: "আমাদের সম্পর্কে" },
  { to: "/admission", label: "ভর্তি তথ্য" },
  { to: "/teachers", label: "শিক্ষকমণ্ডলী" },
  { to: "/success", label: "সাফল্য" },
  { to: "/gallery", label: "গ্যালারি" },
  { to: "/notice", label: "নোটিশ" },
  { to: "/contact", label: "যোগাযোগ" },
];

const admissionLinks = [
  { to: "/admission", label: "ভর্তি তথ্য" },
  { to: "/admission-form", label: "অনলাইন ভর্তি ফরম" },
  { to: "/admission", label: "কোর্সসমূহ" },
  { to: "/admission", label: "ব্যাচ তথ্য" },
];

export default function Footer() {
  const { settings } = useApp();
  const [mapMounted, setMapMounted] = useState(false);

  // Defer the Google Maps iframe until after first paint so Figma Make's
  // renderer isn't blocked waiting for the external URL to resolve.
  useEffect(() => { setMapMounted(true); }, []);

  return (
    <footer style={{ background: "#0f3d20", color: "#bbf7d0", fontFamily: "'Hind Siliguri', sans-serif" }}>
      {/* Main footer */}
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "56px 20px 40px" }}>
        <div style={{
          display: "grid",
          gridTemplateColumns: "2fr 1fr 1fr 2fr",
          gap: 40,
        }}
          className="footer-grid"
        >
          {/* Brand */}
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
              <div style={{
                width: 44, height: 44, borderRadius: 10,
                background: "linear-gradient(135deg, #166534, #22c55e)",
                display: "flex", alignItems: "center", justifyContent: "center",
                color: "white", fontWeight: 700, fontSize: 20, fontFamily: "Lora, serif",
              }}>C</div>
              <div>
                <div style={{ fontFamily: "Lora, serif", fontWeight: 700, fontSize: "1.05rem", color: "white" }}>
                  Commerce Unique Home
                </div>
                <div style={{ fontSize: "0.72rem", color: "#86efac" }}>কমার্স বিভাগের বিশেষজ্ঞ প্রতিষ্ঠান</div>
              </div>
            </div>
            <p style={{ fontSize: "0.88rem", lineHeight: 1.7, color: "#a7f3d0", marginBottom: 20, maxWidth: 280 }}>
              Commerce Unique Home-এ আমরা শিক্ষার্থীদের স্বপ্ন পূরণে সহায়তা করি। আমাদের অভিজ্ঞ শিক্ষকমণ্ডলী ও উন্নত পাঠদান পদ্ধতি শিক্ষার্থীদের সর্বোচ্চ সাফল্য অর্জনে সক্ষম করে।
            </p>
            <div style={{ display: "flex", gap: 10 }}>
              <a
                href={settings.facebook || "#"}
                target="_blank"
                rel="noreferrer"
                style={{
                  width: 36, height: 36, borderRadius: 8,
                  background: "rgba(255,255,255,0.1)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: "#bbf7d0", textDecoration: "none",
                  transition: "background 0.2s",
                }}
                onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.2)")}
                onMouseLeave={e => (e.currentTarget.style.background = "rgba(255,255,255,0.1)")}
              >
                <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                </svg>
              </a>
              <a
                href={settings.whatsapp ? `https://wa.me/${settings.whatsapp.replace(/\D/g, "")}` : "#"}
                target="_blank"
                rel="noreferrer"
                style={{
                  width: 36, height: 36, borderRadius: 8,
                  background: "rgba(255,255,255,0.1)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: "#bbf7d0", textDecoration: "none",
                  transition: "background 0.2s",
                }}
                onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.2)")}
                onMouseLeave={e => (e.currentTarget.style.background = "rgba(255,255,255,0.1)")}
              >
                <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z" />
                </svg>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 style={{ color: "white", fontWeight: 700, marginBottom: 16, fontSize: "0.95rem" }}>দ্রুত লিংক</h4>
            {quickLinks.map(l => (
              <Link
                key={l.to + l.label}
                to={l.to}
                style={{
                  display: "block",
                  color: "#a7f3d0",
                  textDecoration: "none",
                  fontSize: "0.85rem",
                  padding: "4px 0",
                  transition: "color 0.2s",
                }}
                onMouseEnter={e => (e.currentTarget.style.color = "white")}
                onMouseLeave={e => (e.currentTarget.style.color = "#a7f3d0")}
              >
                › {l.label}
              </Link>
            ))}
          </div>

          {/* Admission Links */}
          <div>
            <h4 style={{ color: "white", fontWeight: 700, marginBottom: 16, fontSize: "0.95rem" }}>ভর্তি</h4>
            {admissionLinks.map(l => (
              <Link
                key={l.label}
                to={l.to}
                style={{
                  display: "block",
                  color: "#a7f3d0",
                  textDecoration: "none",
                  fontSize: "0.85rem",
                  padding: "4px 0",
                  transition: "color 0.2s",
                }}
                onMouseEnter={e => (e.currentTarget.style.color = "white")}
                onMouseLeave={e => (e.currentTarget.style.color = "#a7f3d0")}
              >
                › {l.label}
              </Link>
            ))}
            <div style={{ marginTop: 20 }}>
              <h4 style={{ color: "white", fontWeight: 700, marginBottom: 12, fontSize: "0.95rem" }}>যোগাযোগ</h4>
              <div style={{ fontSize: "0.82rem", color: "#a7f3d0", lineHeight: 1.9 }}>
                <div>📍 {settings.address}</div>
                <div>📞 {settings.phone}</div>
                <div>✉️ {settings.email}</div>
                <div>🕐 {settings.openingHours}</div>
              </div>
            </div>
          </div>

          {/* Map */}
          <div>
            <h4 style={{ color: "white", fontWeight: 700, marginBottom: 16, fontSize: "0.95rem" }}>আমাদের অবস্থান</h4>
            <div style={{ borderRadius: 12, overflow: "hidden", height: 180, background: "#1a5c35" }}>
              {mapMounted && (
                <iframe
                  src={settings.mapEmbedUrl}
                  width="100%"
                  height="180"
                  style={{ border: 0, display: "block" }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Commerce Unique Home Location"
                />
              )}
            </div>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent("Commerce Unique Home " + settings.address)}`}
              target="_blank"
              rel="noreferrer"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                marginTop: 10,
                color: "#86efac",
                textDecoration: "none",
                fontSize: "0.85rem",
                fontWeight: 600,
                transition: "color 0.2s",
              }}
              onMouseEnter={e => (e.currentTarget.style.color = "white")}
              onMouseLeave={e => (e.currentTarget.style.color = "#86efac")}
            >
              Google Maps-এ লোকেশন দেখুন →
            </a>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div style={{ borderTop: "1px solid rgba(255,255,255,0.08)", padding: "16px 20px" }}>
        <div style={{
          maxWidth: 1200,
          margin: "0 auto",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          gap: 8,
          fontSize: "0.8rem",
          color: "#6ee7b7",
        }}>
          <span>© ২০২৬ Commerce Unique Home. সর্বস্বত্ব সংরক্ষিত।</span>
          <Link to="/admin" style={{ color: "#6ee7b7", textDecoration: "none", opacity: 0.6 }}>Admin</Link>
        </div>
      </div>

      <style>{`
        @media (max-width: 900px) {
          .footer-grid {
            grid-template-columns: 1fr 1fr !important;
          }
        }
        @media (max-width: 600px) {
          .footer-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </footer>
  );
}
