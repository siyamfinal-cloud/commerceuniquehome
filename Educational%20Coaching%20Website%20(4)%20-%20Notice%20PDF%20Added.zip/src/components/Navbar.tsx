import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";

const navLinks = [
  { to: "/", label: "হোম" },
  { to: "/about", label: "আমাদের সম্পর্কে" },
  { to: "/admission", label: "ভর্তি তথ্য" },
  { to: "/teachers", label: "শিক্ষকমণ্ডলী" },
  { to: "/success", label: "সাফল্য" },
  { to: "/gallery", label: "গ্যালারি" },
  { to: "/notice", label: "নোটিশ" },
  { to: "/contact", label: "যোগাযোগ" },
];

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  return (
    <nav
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        background: scrolled ? "white" : "rgba(255,255,255,0.98)",
        boxShadow: scrolled ? "0 2px 20px rgba(22,101,52,0.12)" : "0 1px 8px rgba(22,101,52,0.06)",
        transition: "box-shadow 0.3s",
      }}
    >
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 20px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: 64 }}>
          {/* Logo */}
          <Link to="/" style={{ textDecoration: "none", display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{
              width: 40, height: 40, borderRadius: 10,
              background: "linear-gradient(135deg, #166534, #16a34a)",
              display: "flex", alignItems: "center", justifyContent: "center",
              color: "white", fontWeight: 700, fontSize: 18, fontFamily: "Lora, serif",
            }}>C</div>
            <div>
              <div style={{ fontFamily: "Lora, serif", fontWeight: 700, fontSize: "1rem", color: "#14532d", lineHeight: 1.2 }}>
                Commerce Unique Home
              </div>
              <div style={{ fontSize: "0.7rem", color: "#16a34a", fontWeight: 500 }}>কমার্স বিভাগের বিশেষজ্ঞ প্রতিষ্ঠান</div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div style={{ display: "flex", alignItems: "center", gap: 4 }} className="hidden-mobile">
            {navLinks.map(link => (
              <Link
                key={link.to}
                to={link.to}
                className={`nav-link ${location.pathname === link.to ? "active" : ""}`}
                style={{ marginRight: 4, fontSize: "0.85rem" }}
              >
                {link.label}
              </Link>
            ))}
            <Link
              to="/admission-form"
              style={{
                marginLeft: 8,
                background: "#166534",
                color: "white",
                padding: "7px 16px",
                borderRadius: 8,
                textDecoration: "none",
                fontWeight: 700,
                fontSize: "0.85rem",
                transition: "background 0.2s",
              }}
              onMouseEnter={e => (e.currentTarget.style.background = "#14532d")}
              onMouseLeave={e => (e.currentTarget.style.background = "#166534")}
            >
              ভর্তি ফরম
            </Link>
          </div>

          {/* Mobile hamburger */}
          <button
            className="show-mobile"
            onClick={() => setMenuOpen(!menuOpen)}
            style={{
              background: "none", border: "none", cursor: "pointer",
              padding: 8, color: "#166534",
            }}
          >
            {menuOpen ? (
              <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M6 18L18 6M6 6l12 12" />
              </svg>
            ) : (
              <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            )}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div style={{
          background: "white",
          borderTop: "1px solid #dcfce7",
          padding: "12px 20px 20px",
          boxShadow: "0 8px 24px rgba(22,101,52,0.1)",
        }}>
          {navLinks.map(link => (
            <Link
              key={link.to}
              to={link.to}
              style={{
                display: "block",
                padding: "10px 0",
                color: location.pathname === link.to ? "#166534" : "#374151",
                fontWeight: location.pathname === link.to ? 700 : 500,
                textDecoration: "none",
                fontSize: "0.95rem",
                borderBottom: "1px solid #f0fdf4",
              }}
            >
              {link.label}
            </Link>
          ))}
          <Link
            to="/admission-form"
            style={{
              display: "block",
              marginTop: 12,
              background: "#166534",
              color: "white",
              padding: "12px",
              borderRadius: 8,
              textDecoration: "none",
              fontWeight: 700,
              textAlign: "center",
              fontSize: "1rem",
            }}
          >
            ভর্তি ফরম পূরণ করুন
          </Link>
        </div>
      )}

      <style>{`
        @media (max-width: 900px) {
          .hidden-mobile { display: none !important; }
          .show-mobile { display: block !important; }
        }
        @media (min-width: 901px) {
          .hidden-mobile { display: flex !important; }
          .show-mobile { display: none !important; }
        }
      `}</style>
    </nav>
  );
}
