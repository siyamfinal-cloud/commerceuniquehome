import { useApp } from "../context/AppContext";

export default function Notice() {
  const { notices } = useApp();

  return (
    <div style={{ paddingTop: 64 }}>
      <div style={{ background: "linear-gradient(135deg, #14532d, #166534)", padding: "64px 20px 80px" }}>
        <div style={{ maxWidth: 700, margin: "0 auto", textAlign: "center" }}>
          <span style={{ display: "inline-block", background: "rgba(187,247,208,0.2)", color: "#86efac", fontSize: "0.8rem", fontWeight: 600, padding: "4px 14px", borderRadius: 100, marginBottom: 14 }}>
            আপডেট
          </span>
          <h1 style={{ fontFamily: "Lora, serif", fontSize: "clamp(1.8rem, 5vw, 2.8rem)", color: "white", fontWeight: 700, marginBottom: 16 }}>
            নোটিশ বোর্ড
          </h1>
          <p style={{ color: "#a7f3d0", fontSize: "0.95rem", lineHeight: 1.8 }}>
            সর্বশেষ নোটিশ, ঘোষণা ও গুরুত্বপূর্ণ তথ্য।
          </p>
        </div>
      </div>

      <section style={{ maxWidth: 860, margin: "0 auto", padding: "60px 20px 80px" }}>
        {notices.length === 0 ? (
          <div style={{ textAlign: "center", color: "#9ca3af", padding: "80px 0" }}>কোনো নোটিশ পাওয়া যায়নি।</div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            {notices.map(n => (
              <div
                key={n.id}
                style={{
                  background: "white",
                  border: `1.5px solid ${n.important ? "#fde68a" : "#dcfce7"}`,
                  borderLeft: `4px solid ${n.important ? "#f59e0b" : "#166534"}`,
                  borderRadius: 12,
                  padding: "24px 28px",
                  boxShadow: "0 4px 16px rgba(22,101,52,0.06)",
                  transition: "box-shadow 0.2s, transform 0.2s",
                }}
                onMouseEnter={e => { e.currentTarget.style.boxShadow = "0 8px 24px rgba(22,101,52,0.12)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
                onMouseLeave={e => { e.currentTarget.style.boxShadow = "0 4px 16px rgba(22,101,52,0.06)"; e.currentTarget.style.transform = "translateY(0)"; }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16, flexWrap: "wrap", marginBottom: 12 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    {n.important && (
                      <span style={{
                        background: "#fef3c7", color: "#b45309",
                        fontSize: "0.72rem", fontWeight: 700,
                        padding: "3px 10px", borderRadius: 100,
                      }}>
                        ⚠️ গুরুত্বপূর্ণ
                      </span>
                    )}
                    <h3 style={{ fontFamily: "Lora, serif", fontWeight: 700, color: "#14532d", fontSize: "1rem", margin: 0 }}>
                      {n.title}
                    </h3>
                  </div>
                  <div style={{
                    background: "#f0fdf4",
                    color: "#166534",
                    fontSize: "0.78rem",
                    fontWeight: 600,
                    padding: "4px 10px",
                    borderRadius: 8,
                    whiteSpace: "nowrap",
                  }}>
                    📅 {n.date}
                  </div>
                </div>
                <p style={{ color: "#6b7280", fontSize: "0.9rem", lineHeight: 1.8, margin: 0 }}>{n.content}</p>
                {n.pdfUrl && (
                  <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 18 }}>
                    <a
                      href={n.pdfUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{ display: "inline-flex", alignItems: "center", gap: 7, padding: "8px 14px", background: "#166534", color: "white", borderRadius: 8, textDecoration: "none", fontSize: "0.82rem", fontWeight: 700 }}
                    >
                      📄 PDF দেখুন
                    </a>
                    <a
                      href={n.pdfUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      download
                      style={{ display: "inline-flex", alignItems: "center", gap: 7, padding: "8px 14px", background: "white", color: "#166534", border: "1px solid #86efac", borderRadius: 8, textDecoration: "none", fontSize: "0.82rem", fontWeight: 700 }}
                    >
                      ⬇️ Download PDF
                    </a>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
