import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useApp } from "../../context/AppContext";

export default function AdminLogin() {
  const { adminLogin, isAdminLoggedIn } = useApp();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isAdminLoggedIn) navigate("/admin/dashboard");
  }, [isAdminLoggedIn, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setError("ইমেইল এবং পাসওয়ার্ড দিন।");
      return;
    }
    setLoading(true);
    setError("");
    const result = await adminLogin(email.trim(), password);
    if (result.error) {
      setError("লগইন ব্যর্থ: " + result.error);
      setLoading(false);
    } else {
      navigate("/admin/dashboard");
    }
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(135deg, #0f3d20, #14532d)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "20px",
      }}
    >
      <div
        style={{
          background: "white",
          borderRadius: 20,
          padding: "48px 40px",
          maxWidth: 420,
          width: "100%",
          boxShadow: "0 32px 80px rgba(0,0,0,0.3)",
        }}
      >
        <div style={{ textAlign: "center", marginBottom: 36 }}>
          <div
            style={{
              width: 64,
              height: 64,
              borderRadius: 16,
              background: "linear-gradient(135deg, #166534, #16a34a)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 16px",
              color: "white",
              fontWeight: 700,
              fontSize: 28,
              fontFamily: "Lora, serif",
            }}
          >
            C
          </div>
          <h1
            style={{
              fontFamily: "Lora, serif",
              fontWeight: 700,
              fontSize: "1.5rem",
              color: "#14532d",
              marginBottom: 6,
            }}
          >
            Admin Panel
          </h1>
          <p style={{ color: "#9ca3af", fontSize: "0.88rem" }}>
            Commerce Unique Home
          </p>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          <div style={{ marginBottom: 16 }}>
            <label
              style={{
                display: "block",
                fontWeight: 600,
                color: "#374151",
                fontSize: "0.88rem",
                marginBottom: 6,
              }}
            >
              ইমেইল
            </label>
            <input
              type="email"
              className="form-input"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setError("");
              }}
              placeholder="admin@example.com"
              autoFocus
              autoComplete="email"
            />
          </div>

          <div style={{ marginBottom: 20 }}>
            <label
              style={{
                display: "block",
                fontWeight: 600,
                color: "#374151",
                fontSize: "0.88rem",
                marginBottom: 6,
              }}
            >
              পাসওয়ার্ড
            </label>
            <input
              type="password"
              className="form-input"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError("");
              }}
              placeholder="••••••••"
              autoComplete="current-password"
            />
          </div>

          {error && (
            <div
              style={{
                background: "#fef2f2",
                border: "1px solid #fecaca",
                borderRadius: 8,
                padding: "10px 14px",
                color: "#dc2626",
                fontSize: "0.84rem",
                marginBottom: 16,
                display: "flex",
                alignItems: "center",
                gap: 6,
              }}
            >
              ⚠️ {error}
            </div>
          )}

          <button
            type="submit"
            className="btn-primary"
            style={{
              width: "100%",
              justifyContent: "center",
              padding: "12px",
              fontSize: "1rem",
              opacity: loading ? 0.7 : 1,
            }}
            disabled={loading}
          >
            {loading ? "লগইন হচ্ছে..." : "লগইন করুন →"}
          </button>
        </form>

        <div style={{ marginTop: 24, textAlign: "center" }}>
          <p style={{ fontSize: "0.78rem", color: "#9ca3af", lineHeight: 1.6 }}>
            Supabase Auth দ্বারা সুরক্ষিত।
            <br />
            Admin অ্যাকাউন্ট Supabase Dashboard থেকে তৈরি করুন।
          </p>
        </div>
      </div>
    </div>
  );
}
