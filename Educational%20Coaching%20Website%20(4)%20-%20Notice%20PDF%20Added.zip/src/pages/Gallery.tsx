import { useState } from "react";
import { useApp } from "../context/AppContext";

export default function Gallery() {
  const { gallery } = useApp();
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [filter, setFilter] = useState("সব");

  const categories = ["সব", ...Array.from(new Set(gallery.map(g => g.category)))];
  const filtered = filter === "সব" ? gallery : gallery.filter(g => g.category === filter);

  return (
    <div style={{ paddingTop: 64 }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #14532d, #166534)", padding: "64px 20px 80px" }}>
        <div style={{ maxWidth: 700, margin: "0 auto", textAlign: "center" }}>
          <span style={{ display: "inline-block", background: "rgba(187,247,208,0.2)", color: "#86efac", fontSize: "0.8rem", fontWeight: 600, padding: "4px 14px", borderRadius: 100, marginBottom: 14 }}>
            আমাদের মুহূর্ত
          </span>
          <h1 style={{ fontFamily: "Lora, serif", fontSize: "clamp(1.8rem, 5vw, 2.8rem)", color: "white", fontWeight: 700, marginBottom: 16 }}>
            গ্যালারি
          </h1>
          <p style={{ color: "#a7f3d0", fontSize: "0.95rem", lineHeight: 1.8 }}>
            Commerce Unique Home-এর বিভিন্ন কার্যক্রম, পরীক্ষা ও অনুষ্ঠানের স্মৃতিময় মুহূর্ত।
          </p>
        </div>
      </div>

      <section style={{ maxWidth: 1200, margin: "0 auto", padding: "60px 20px 80px" }}>
        {/* Category filter */}
        <div style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap", marginBottom: 40 }}>
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              style={{
                padding: "7px 18px",
                borderRadius: 100,
                border: "1.5px solid",
                borderColor: filter === cat ? "#166534" : "#dcfce7",
                background: filter === cat ? "#166534" : "white",
                color: filter === cat ? "white" : "#374151",
                fontWeight: 600,
                fontSize: "0.84rem",
                cursor: "pointer",
                fontFamily: "inherit",
                transition: "all 0.2s",
              }}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid */}
        {filtered.length === 0 ? (
          <div style={{ textAlign: "center", color: "#9ca3af", padding: "80px 20px" }}>কোনো ছবি পাওয়া যায়নি।</div>
        ) : (
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: 16,
            gridAutoRows: "240px",
          }} className="gallery-grid">
            {filtered.map((item, i) => (
              <div
                key={item.id}
                className="gallery-item"
                onClick={() => setLightbox(item.url)}
                style={{
                  gridRow: i % 5 === 0 ? "span 2" : "span 1",
                }}
              >
                <img src={item.url || undefined} alt={item.caption} loading="lazy" style={{ background: "#dcfce7" }} />
                <div className="overlay">
                  <div style={{ textAlign: "center", color: "white" }}>
                    <div style={{ fontSize: "2rem", marginBottom: 8 }}>🔍</div>
                    <div style={{ fontWeight: 600, fontSize: "0.9rem" }}>{item.caption}</div>
                    <div style={{ fontSize: "0.78rem", marginTop: 4, opacity: 0.8 }}>{item.category}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Lightbox */}
      {lightbox && (
        <div className="modal-backdrop" onClick={() => setLightbox(null)}>
          <div style={{ position: "relative", maxWidth: "90vw", maxHeight: "90vh" }}>
            <img
              src={lightbox}
              alt="Gallery"
              style={{ maxWidth: "90vw", maxHeight: "85vh", borderRadius: 12, objectFit: "contain", boxShadow: "0 32px 80px rgba(0,0,0,0.5)" }}
            />
            <button
              onClick={() => setLightbox(null)}
              style={{
                position: "absolute",
                top: -16, right: -16,
                width: 40, height: 40,
                borderRadius: "50%",
                background: "white",
                border: "none",
                cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: "1.2rem", fontWeight: 700, color: "#374151",
                boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
              }}
            >
              ×
            </button>
          </div>
        </div>
      )}

      <style>{`
        @media(max-width:768px){
          .gallery-grid{grid-template-columns:repeat(2,1fr)!important;grid-auto-rows:180px!important;}
        }
        @media(max-width:480px){
          .gallery-grid{grid-template-columns:1fr!important;grid-auto-rows:220px!important;}
        }
      `}</style>
    </div>
  );
}
