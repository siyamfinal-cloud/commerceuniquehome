import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { supabase } from "../lib/supabase";

const faqs = [
  { q: "ভর্তি কখন শুরু?", a: "প্রতি বছর জুলাই-আগস্ট মাসে ভর্তি কার্যক্রম শুরু হয়। বর্তমানে ২০২৬ শিক্ষাবর্ষের ভর্তি চলছে।" },
  { q: "কোন কোন ব্যাচে ভর্তি নেওয়া হচ্ছে?", a: "HSC কমার্স (একাদশ ও দ্বাদশ শ্রেণি), SSC কমার্স (নবম-দশম) এবং HSC ক্র্যাশ প্রোগ্রামে ভর্তি নেওয়া হচ্ছে।" },
  { q: "ভর্তি ফি কত?", a: "কোর্স অনুযায়ী ভর্তি ফি ৳১,০০০ থেকে ৳১,৫০০ পর্যন্ত। বিস্তারিত কোর্স কার্ডে দেখুন।" },
  { q: "মাসিক বেতন কত?", a: "মাসিক বেতন ৳৮০০ থেকে ৳১,২০০ পর্যন্ত কোর্সভেদে ভিন্ন হয়।" },
  { q: "ক্লাসের সময়সূচি কী?", a: "সকাল ৭টা থেকে রাত ৯টার মধ্যে বিভিন্ন শিফটে ক্লাস পরিচালিত হয়। প্রতিটি ব্যাচের নির্দিষ্ট সময়সূচি কোর্স কার্ডে উল্লেখ আছে।" },
  { q: "অনলাইনে ভর্তি করা যাবে কি?", a: "হ্যাঁ, আমাদের ওয়েবসাইটের 'ভর্তি ফরম' পেজে গিয়ে অনলাইনে আবেদন করা যাবে। আবেদনের পর আমাদের প্রতিনিধি যোগাযোগ করবেন।" },
];

const documents = [
  "জন্ম নিবন্ধন সনদ / জন্ম সার্টিফিকেটের কপি",
  "সর্বশেষ পরীক্ষার মার্কশিট ও সনদপত্র",
  "পাসপোর্ট সাইজের ২ কপি ছবি",
  "অভিভাবকের জাতীয় পরিচয়পত্রের কপি",
  "ভর্তি ফরম পূরণ করা",
  "ভর্তি ফি প্রদানের রসিদ",
];

interface CourseRow {
  id: string;
  name: string;
  classes: string;
  schedule: string;
  admission_fee: string;
  monthly_fee: string;
  term: string;
  start_date: string;
  timing: string;
}

export default function AdmissionDetails() {
  const [courses, setCourses] = useState<CourseRow[]>([]);
  const [loadingCourses, setLoadingCourses] = useState(true);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoadingCourses(true);

    const load = async () => {
      const { data, error } = await supabase
        .from("cuh_courses")
        .select("id, name, classes, schedule, admission_fee, monthly_fee, term, start_date, timing")
        .order("created_at", { ascending: true });

      if (!cancelled) {
        if (error) {
          console.info("[AdmissionDetails] fetch error:", error.message);
        } else {
          setCourses((data ?? []) as CourseRow[]);
        }
        setLoadingCourses(false);
      }
    };

    load();
    return () => { cancelled = true; };
  }, []);

  return (
    <div style={{ paddingTop: 64 }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #14532d, #166534)", padding: "64px 20px 80px" }}>
        <div style={{ maxWidth: 800, margin: "0 auto", textAlign: "center" }}>
          <span style={{ display: "inline-block", background: "rgba(187,247,208,0.2)", color: "#86efac", fontSize: "0.8rem", fontWeight: 600, padding: "4px 14px", borderRadius: 100, marginBottom: 16 }}>
            ২০২৬ শিক্ষাবর্ষ
          </span>
          <h1 style={{ fontFamily: "Lora, serif", fontSize: "clamp(1.8rem, 5vw, 2.8rem)", color: "white", fontWeight: 700, marginBottom: 16 }}>
            ভর্তি তথ্য
          </h1>
          <p style={{ color: "#a7f3d0", fontSize: "0.95rem", lineHeight: 1.8 }}>
            Commerce Unique Home-এ ভর্তির বিস্তারিত তথ্য, কোর্স ও ফি সম্পর্কে জানুন।
          </p>
        </div>
      </div>

      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 20px" }}>
        {/* Courses */}
        <section style={{ padding: "60px 0" }}>
          <h2 style={{ fontFamily: "Lora, serif", fontSize: "clamp(1.4rem, 3vw, 2rem)", color: "#14532d", fontWeight: 700, marginBottom: 32 }}>
            কোর্সসমূহ ও ব্যাচ তথ্য
          </h2>

          {loadingCourses ? (
            <div style={{ textAlign: "center", padding: "40px 0", color: "#6b7280", fontSize: "0.9rem" }}>
              কোর্স তথ্য লোড হচ্ছে...
            </div>
          ) : courses.length === 0 ? (
            <div style={{ textAlign: "center", padding: "40px 0", color: "#9ca3af", fontSize: "0.9rem" }}>
              বর্তমানে কোনো কোর্স পাওয়া যাচ্ছে না।
            </div>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 24 }} className="courses-grid">
              {courses.map((c, i) => (
                <div
                  key={c.id}
                  style={{
                    background: "white",
                    border: i === 0 ? "2px solid #166534" : "1.5px solid #dcfce7",
                    borderRadius: 16,
                    overflow: "hidden",
                    boxShadow: i === 0 ? "0 8px 32px rgba(22,101,52,0.15)" : "0 4px 16px rgba(22,101,52,0.06)",
                    position: "relative",
                  }}
                >
                  {i === 0 && (
                    <div style={{
                      background: "#166534", color: "white",
                      textAlign: "center", padding: "8px",
                      fontSize: "0.78rem", fontWeight: 700,
                    }}>
                      ✦ সবচেয়ে জনপ্রিয়
                    </div>
                  )}
                  <div style={{ padding: "24px" }}>
                    <h3 style={{ fontFamily: "Lora, serif", fontWeight: 700, color: "#14532d", fontSize: "1.05rem", marginBottom: 8 }}>{c.name}</h3>
                    <div style={{ color: "#6b7280", fontSize: "0.82rem", marginBottom: 20, lineHeight: 1.7 }}>
                      <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6 }}>
                        <span style={{ width: 16, textAlign: "center" }}>📚</span> শ্রেণি: {c.classes}
                      </div>
                      <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6 }}>
                        <span style={{ width: 16, textAlign: "center" }}>📅</span> শুরু: {c.start_date}
                      </div>
                      <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6 }}>
                        <span style={{ width: 16, textAlign: "center" }}>🕐</span> সময়: {c.timing}
                      </div>
                      <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6 }}>
                        <span style={{ width: 16, textAlign: "center" }}>⏱️</span> মেয়াদ: {c.term}
                      </div>
                      <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6 }}>
                        <span style={{ width: 16, textAlign: "center" }}>📆</span> সময়সূচি: {c.schedule}
                      </div>
                    </div>
                    <div style={{ borderTop: "1px solid #f0fdf4", paddingTop: 16, marginBottom: 16 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                        <span style={{ color: "#6b7280", fontSize: "0.82rem" }}>ভর্তি ফি</span>
                        <span style={{ fontWeight: 700, color: "#14532d", fontSize: "0.95rem" }}>{c.admission_fee}</span>
                      </div>
                      <div style={{ display: "flex", justifyContent: "space-between" }}>
                        <span style={{ color: "#6b7280", fontSize: "0.82rem" }}>মাসিক বেতন</span>
                        <span style={{ fontWeight: 700, color: "#14532d", fontSize: "0.95rem" }}>{c.monthly_fee}</span>
                      </div>
                    </div>
                    <Link
                      to="/admission-form"
                      style={{
                        display: "block",
                        background: i === 0 ? "#166534" : "white",
                        color: i === 0 ? "white" : "#166534",
                        border: `2px solid #166534`,
                        borderRadius: 8,
                        padding: "10px",
                        textAlign: "center",
                        textDecoration: "none",
                        fontWeight: 700,
                        fontSize: "0.88rem",
                        transition: "all 0.2s",
                      }}
                      onMouseEnter={e => {
                        e.currentTarget.style.background = "#14532d";
                        e.currentTarget.style.color = "white";
                      }}
                      onMouseLeave={e => {
                        e.currentTarget.style.background = i === 0 ? "#166534" : "white";
                        e.currentTarget.style.color = i === 0 ? "white" : "#166534";
                      }}
                    >
                      ভর্তি ফরম পূরণ করুন
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Procedure & Documents */}
        <section style={{ padding: "0 0 60px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40 }} className="proc-grid">
          <div>
            <h2 style={{ fontFamily: "Lora, serif", fontSize: "1.4rem", color: "#14532d", fontWeight: 700, marginBottom: 24 }}>
              ভর্তির পদ্ধতি
            </h2>
            {[
              { step: "১", title: "অনলাইন আবেদন", desc: "ভর্তি ফরম পূরণ করে অনলাইনে জমা দিন।" },
              { step: "২", title: "যোগাযোগ", desc: "আমাদের প্রতিনিধি ফোন করে সময় নির্ধারণ করবেন।" },
              { step: "৩", title: "কাগজপত্র জমা", desc: "নির্দিষ্ট দিনে প্রয়োজনীয় কাগজপত্র নিয়ে আসুন।" },
              { step: "৪", title: "ফি পরিশোধ", desc: "ভর্তি ফি পরিশোধ করুন এবং ব্যাচ নিশ্চিত করুন।" },
              { step: "৫", title: "ক্লাস শুরু", desc: "নির্ধারিত তারিখ থেকে ক্লাস শুরু করুন।" },
            ].map(s => (
              <div key={s.step} style={{ display: "flex", gap: 16, marginBottom: 20 }}>
                <div style={{
                  width: 36, height: 36, borderRadius: "50%",
                  background: "#166534", color: "white",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontWeight: 700, fontSize: "0.9rem", flexShrink: 0,
                }}>
                  {s.step}
                </div>
                <div>
                  <div style={{ fontWeight: 700, color: "#14532d", marginBottom: 4, fontSize: "0.92rem" }}>{s.title}</div>
                  <div style={{ color: "#6b7280", fontSize: "0.84rem" }}>{s.desc}</div>
                </div>
              </div>
            ))}
          </div>

          <div>
            <h2 style={{ fontFamily: "Lora, serif", fontSize: "1.4rem", color: "#14532d", fontWeight: 700, marginBottom: 24 }}>
              প্রয়োজনীয় কাগজপত্র
            </h2>
            {documents.map(d => (
              <div key={d} style={{
                display: "flex", gap: 12, alignItems: "flex-start",
                background: "#f0fdf4", border: "1.5px solid #dcfce7",
                borderRadius: 10, padding: "12px 16px", marginBottom: 10,
              }}>
                <span style={{ color: "#16a34a", fontWeight: 700, fontSize: "1rem", flexShrink: 0 }}>✓</span>
                <span style={{ color: "#374151", fontSize: "0.88rem" }}>{d}</span>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* FAQ */}
      <section style={{ background: "#f0fdf4", padding: "80px 20px" }}>
        <div style={{ maxWidth: 800, margin: "0 auto" }}>
          <h2 style={{ fontFamily: "Lora, serif", fontSize: "clamp(1.4rem, 3vw, 2rem)", color: "#14532d", fontWeight: 700, marginBottom: 40, textAlign: "center" }}>
            সাধারণ জিজ্ঞাসা (FAQ)
          </h2>
          {faqs.map((f, i) => (
            <div
              key={i}
              style={{
                background: "white",
                border: "1.5px solid #dcfce7",
                borderRadius: 12,
                marginBottom: 12,
                overflow: "hidden",
              }}
            >
              <button
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                style={{
                  width: "100%", padding: "18px 20px",
                  background: "none", border: "none", cursor: "pointer",
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                  textAlign: "left",
                }}
              >
                <span style={{ fontWeight: 700, color: "#14532d", fontSize: "0.92rem", flex: 1 }}>{f.q}</span>
                <span style={{ color: "#16a34a", fontSize: "1.2rem", marginLeft: 12, transition: "transform 0.2s", transform: openFaq === i ? "rotate(45deg)" : "none" }}>+</span>
              </button>
              {openFaq === i && (
                <div style={{ padding: "0 20px 18px", color: "#6b7280", fontSize: "0.88rem", lineHeight: 1.8, borderTop: "1px solid #f0fdf4" }}>
                  {f.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      <style>{`
        @media(max-width:900px){.courses-grid{grid-template-columns:1fr!important;}}
        @media(max-width:640px){.proc-grid{grid-template-columns:1fr!important;}}
      `}</style>
    </div>
  );
}
