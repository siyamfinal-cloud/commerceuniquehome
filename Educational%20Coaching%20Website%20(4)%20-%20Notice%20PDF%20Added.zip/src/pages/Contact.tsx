import { useApp } from "../context/AppContext";
import { useState } from "react";

export default function Contact() {
  const { settings } = useApp();
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", email: "", message: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <div style={{ paddingTop: 64 }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #14532d, #166534)", padding: "64px 20px 80px" }}>
        <div style={{ maxWidth: 700, margin: "0 auto", textAlign: "center" }}>
          <span style={{ display: "inline-block", background: "rgba(187,247,208,0.2)", color: "#86efac", fontSize: "0.8rem", fontWeight: 600, padding: "4px 14px", borderRadius: 100, marginBottom: 14 }}>
            আমাদের সাথে যোগাযোগ করুন
          </span>
          <h1 style={{ fontFamily: "Lora, serif", fontSize: "clamp(1.8rem, 5vw, 2.8rem)", color: "white", fontWeight: 700, marginBottom: 16 }}>
            যোগাযোগ
          </h1>
          <p style={{ color: "#a7f3d0", fontSize: "0.95rem", lineHeight: 1.8 }}>
            যেকোনো প্রশ্ন বা তথ্যের জন্য আমাদের সাথে যোগাযোগ করুন।
          </p>
        </div>
      </div>

      <section style={{ maxWidth: 1200, margin: "0 auto", padding: "60px 20px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: 48, alignItems: "start" }} className="contact-grid">
          {/* Info */}
          <div>
            <h2 style={{ fontFamily: "Lora, serif", fontSize: "1.5rem", color: "#14532d", fontWeight: 700, marginBottom: 32 }}>
              যোগাযোগের তথ্য
            </h2>
            {[
              { icon: "📍", label: "ঠিকানা", value: settings.address },
              { icon: "📞", label: "ফোন", value: settings.phone, href: `tel:${settings.phone}` },
              { icon: "💬", label: "WhatsApp", value: settings.whatsapp, href: `https://wa.me/${settings.whatsapp.replace(/\D/g, "")}` },
              { icon: "✉️", label: "ইমেইল", value: settings.email, href: `mailto:${settings.email}` },
              { icon: "🕐", label: "সময়সূচি", value: settings.openingHours },
            ].map(item => (
              <div
                key={item.label}
                style={{
                  display: "flex",
                  gap: 16,
                  marginBottom: 20,
                  background: "white",
                  border: "1.5px solid #dcfce7",
                  borderRadius: 12,
                  padding: "16px 20px",
                  boxShadow: "0 2px 10px rgba(22,101,52,0.05)",
                }}
              >
                <div style={{ fontSize: "1.4rem", flexShrink: 0 }}>{item.icon}</div>
                <div>
                  <div style={{ fontWeight: 700, color: "#14532d", fontSize: "0.82rem", marginBottom: 4 }}>{item.label}</div>
                  {item.href ? (
                    <a href={item.href} target={item.href.startsWith("http") ? "_blank" : undefined} rel="noreferrer"
                      style={{ color: "#166534", textDecoration: "none", fontSize: "0.9rem", fontWeight: 500 }}>
                      {item.value}
                    </a>
                  ) : (
                    <div style={{ color: "#374151", fontSize: "0.9rem" }}>{item.value}</div>
                  )}
                </div>
              </div>
            ))}

            {/* Facebook */}
            <div style={{ marginTop: 8 }}>
              <a
                href={settings.facebook || "#"}
                target="_blank"
                rel="noreferrer"
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 8,
                  background: "#1877f2",
                  color: "white",
                  padding: "10px 20px",
                  borderRadius: 10,
                  textDecoration: "none",
                  fontWeight: 700,
                  fontSize: "0.88rem",
                }}
              >
                <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" /></svg>
                Facebook পেজ দেখুন
              </a>
            </div>

            {/* Get Directions */}
            <div style={{ marginTop: 16 }}>
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent("Commerce Unique Home " + settings.address)}`}
                target="_blank"
                rel="noreferrer"
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 8,
                  background: "#166534",
                  color: "white",
                  padding: "10px 20px",
                  borderRadius: 10,
                  textDecoration: "none",
                  fontWeight: 700,
                  fontSize: "0.88rem",
                }}
              >
                📍 Get Directions
              </a>
            </div>
          </div>

          {/* Form */}
          <div>
            <div style={{
              background: "white",
              border: "1.5px solid #dcfce7",
              borderRadius: 20,
              padding: "36px",
              boxShadow: "0 8px 32px rgba(22,101,52,0.08)",
            }}>
              {sent ? (
                <div style={{ textAlign: "center", padding: "40px 0" }}>
                  <div style={{ fontSize: "3rem", marginBottom: 16 }}>✅</div>
                  <h3 style={{ fontFamily: "Lora, serif", color: "#14532d", fontWeight: 700, fontSize: "1.3rem", marginBottom: 12 }}>
                    বার্তা পাঠানো হয়েছে!
                  </h3>
                  <p style={{ color: "#6b7280", fontSize: "0.9rem", lineHeight: 1.8 }}>
                    আমরা যত দ্রুত সম্ভব আপনার সাথে যোগাযোগ করব।
                  </p>
                </div>
              ) : (
                <>
                  <h2 style={{ fontFamily: "Lora, serif", fontWeight: 700, color: "#14532d", fontSize: "1.3rem", marginBottom: 24 }}>
                    বার্তা পাঠান
                  </h2>
                  <form onSubmit={handleSubmit}>
                    {[
                      { label: "আপনার নাম", key: "name", type: "text", placeholder: "নাম লিখুন" },
                      { label: "মোবাইল নম্বর", key: "phone", type: "tel", placeholder: "০১XXXXXXXXX" },
                      { label: "ইমেইল (ঐচ্ছিক)", key: "email", type: "email", placeholder: "email@example.com" },
                    ].map(f => (
                      <div key={f.key} style={{ marginBottom: 18 }}>
                        <label style={{ display: "block", fontWeight: 600, color: "#374151", fontSize: "0.88rem", marginBottom: 6 }}>{f.label}</label>
                        <input
                          type={f.type}
                          placeholder={f.placeholder}
                          value={form[f.key as keyof typeof form]}
                          onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                          className="form-input"
                        />
                      </div>
                    ))}
                    <div style={{ marginBottom: 24 }}>
                      <label style={{ display: "block", fontWeight: 600, color: "#374151", fontSize: "0.88rem", marginBottom: 6 }}>আপনার বার্তা</label>
                      <textarea
                        className="form-input"
                        style={{ height: 120, resize: "vertical" }}
                        placeholder="আপনার প্রশ্ন বা বার্তা লিখুন..."
                        value={form.message}
                        onChange={e => setForm(p => ({ ...p, message: e.target.value }))}
                      />
                    </div>
                    <button type="submit" className="btn-primary" style={{ width: "100%", justifyContent: "center", padding: "12px" }}>
                      বার্তা পাঠান →
                    </button>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Map */}
        <div style={{ marginTop: 60 }}>
          <h2 style={{ fontFamily: "Lora, serif", fontSize: "1.4rem", color: "#14532d", fontWeight: 700, marginBottom: 20 }}>
            আমাদের অবস্থান
          </h2>
          <div style={{ borderRadius: 16, overflow: "hidden", boxShadow: "0 8px 32px rgba(22,101,52,0.1)", border: "2px solid #dcfce7" }}>
            <iframe
              src={settings.mapEmbedUrl}
              width="100%"
              height="400"
              style={{ border: 0, display: "block" }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Commerce Unique Home Location"
            />
          </div>
        </div>
      </section>

      <style>{`@media(max-width:768px){.contact-grid{grid-template-columns:1fr!important;}}`}</style>
    </div>
  );
}
